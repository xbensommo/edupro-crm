/**
 * @file auth/utils/inviteAccess.helpers.js
 * @description Pure helpers for invite-only registration and access enforcement.
 */

const ACCESS_STATUSES = Object.freeze({
  ACTIVE: 'active',
  PENDING_INVITE: 'pending_invite',
  SUSPENDED: 'suspended',
  DISABLED: 'disabled',
});

const INVITE_STATUSES = Object.freeze({
  PENDING: 'pending',
  ACCEPTED: 'accepted',
  REVOKED: 'revoked',
  EXPIRED: 'expired',
});

/**
 * Create a normalized email key for comparisons.
 *
 * @param {string} email
 * @returns {string}
 */
export function normalizeEmail(email) {
  return String(email || '').trim().toLowerCase();
}

/**
 * Ensure a value is always an array of unique non-empty strings.
 *
 * @param {string|string[]|null|undefined} value
 * @returns {string[]}
 */
export function normalizeStringArray(value) {
  const items = Array.isArray(value) ? value : [value].filter(Boolean);
  return [...new Set(items.map((item) => String(item || '').trim()).filter(Boolean))];
}

/**
 * Generate an opaque invite token.
 *
 * @returns {string}
 */
export function generateInviteToken() {
  const bytes = globalThis.crypto?.getRandomValues
    ? globalThis.crypto.getRandomValues(new Uint8Array(32))
    : Array.from({ length: 32 }, () => Math.floor(Math.random() * 256));

  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
}

/**
 * Hash the invite token so the raw token does not need to be stored in Firestore.
 *
 * @param {string} token
 * @returns {Promise<string>}
 */
export async function hashInviteToken(token) {
  const normalized = String(token || '').trim();

  if (!normalized) {
    throw createAccessError('auth/invalid-invite-token', 'The invitation token is invalid.');
  }

  if (globalThis.crypto?.subtle) {
    const encoded = new TextEncoder().encode(normalized);
    const digest = await globalThis.crypto.subtle.digest('SHA-256', encoded);
    return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('');
  }

  return normalized;
}

/**
 * Build an app error with a stable code.
 *
 * @param {string} code
 * @param {string} message
 * @param {object} [meta={}]
 * @returns {Error & { code: string, meta: object }}
 */
export function createAccessError(code, message, meta = {}) {
  const error = new Error(message);
  error.code = code;
  error.meta = meta;
  return error;
}

/**
 * Return a future expiry date from a preset.
 *
 * @param {string} preset
 * @param {Date} [now=new Date()]
 * @returns {Date}
 */
export function resolveInviteExpiry(preset = '72h', now = new Date()) {
  const base = new Date(now);
  const map = {
    '24h': 24,
    '48h': 48,
    '72h': 72,
    '7d': 24 * 7,
    '14d': 24 * 14,
  };

  const hours = map[preset] || map['72h'];
  base.setHours(base.getHours() + hours);
  return base;
}

/**
 * Determine whether an invite is still usable.
 *
 * @param {object|null|undefined} invite
 * @param {Date} [now=new Date()]
 * @returns {boolean}
 */
export function isInviteUsable(invite, now = new Date()) {
  if (!invite) return false;
  const expiresAt = new Date(invite.expiresAt || 0);
  return invite.status === INVITE_STATUSES.PENDING && expiresAt.getTime() > now.getTime();
}

/**
 * Determine whether a user profile should be allowed into the app.
 *
 * @param {object|null|undefined} profile
 * @returns {boolean}
 */
export function isActiveProfile(profile) {
  return Boolean(profile && profile.status === ACCESS_STATUSES.ACTIVE);
}

/**
 * Infer the effective access status from a profile.
 *
 * @param {object|null|undefined} profile
 * @returns {string}
 */
export function resolveAccessStatus(profile) {
  return profile?.status || ACCESS_STATUSES.PENDING_INVITE;
}

/**
 * Validate a profile before route access or state sync.
 *
 * @param {object|null|undefined} profile
 * @returns {void}
 */
export function assertProfileCanAccess(profile) {
  if (!profile) {
    throw createAccessError('auth/profile-missing', 'Your user profile was not found. Contact an administrator.');
  }

  const status = resolveAccessStatus(profile);

  if (status === ACCESS_STATUSES.SUSPENDED) {
    throw createAccessError('auth/account-suspended', 'Your account has been suspended. Contact an administrator.');
  }

  if (status === ACCESS_STATUSES.DISABLED) {
    throw createAccessError('auth/account-disabled', 'Your account is disabled. Contact an administrator.');
  }

  if (status !== ACCESS_STATUSES.ACTIVE) {
    throw createAccessError('auth/access-denied', 'Your account is not active yet. Contact an administrator.');
  }
}

export { ACCESS_STATUSES, INVITE_STATUSES };

export default {
  ACCESS_STATUSES,
  INVITE_STATUSES,
  normalizeEmail,
  normalizeStringArray,
  generateInviteToken,
  hashInviteToken,
  createAccessError,
  resolveInviteExpiry,
  isInviteUsable,
  isActiveProfile,
  resolveAccessStatus,
  assertProfileCanAccess,
};
