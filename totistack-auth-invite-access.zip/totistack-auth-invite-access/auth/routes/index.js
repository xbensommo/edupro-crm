/**
 * @file auth/routes/index.js
 * @description Route contribution for invite-only auth access management.
 */

export default function createAuthInviteRoutes() {
  return [
    {
      path: '/accept-invite',
      name: 'accept-invite',
      component: () => import('../pages/AcceptInvitePage.vue'),
      meta: {
        requiresAuth: false,
        layout: 'auth',
        title: 'Accept invitation',
      },
    },
    {
      path: '/admin/team-access',
      name: 'team-access',
      component: () => import('../pages/TeamAccessPage.vue'),
      meta: {
        requiresAuth: true,
        permissions: ['auth.invites.read'],
        title: 'Team access',
      },
    },
  ];
}
