import { defineStore } from 'pinia';
import { computed, ref } from 'vue';

/**
 * @file auth/stores/useTeamAccessStore.js
 * @description Thin state layer for the admin/receptionist team access pages.
 */
export const useTeamAccessStore = defineStore('teamAccessStore', () => {
  const snapshot = ref({ users: [], invites: [], metrics: {} });
  const loading = ref(false);
  const error = ref(null);

  const pendingInvites = computed(() => snapshot.value.invites.filter((item) => item.status === 'pending'));
  const acceptedInvites = computed(() => snapshot.value.invites.filter((item) => item.status === 'accepted'));
  const expiredInvites = computed(() => snapshot.value.invites.filter((item) => item.status === 'expired'));
  const revokedInvites = computed(() => snapshot.value.invites.filter((item) => item.status === 'revoked'));
  const suspendedUsers = computed(() => snapshot.value.users.filter((item) => item.status === 'suspended'));

  async function load(service) {
    loading.value = true;
    error.value = null;
    try {
      snapshot.value = await service.loadTeamAccessSnapshot();
      return snapshot.value;
    } catch (err) {
      error.value = err;
      throw err;
    } finally {
      loading.value = false;
    }
  }

  async function createInvite(service, payload) {
    loading.value = true;
    error.value = null;
    try {
      const created = await service.createInvite(payload);
      await load(service);
      return created;
    } catch (err) {
      error.value = err;
      throw err;
    } finally {
      loading.value = false;
    }
  }

  async function revokeInvite(service, inviteId) {
    await service.revokeInvite(inviteId);
    await load(service);
  }

  async function extendInvite(service, inviteId, expiresAt) {
    await service.extendInvite(inviteId, expiresAt);
    await load(service);
  }

  async function suspendUser(service, userId, reason) {
    await service.suspendUser(userId, reason);
    await load(service);
  }

  async function reactivateUser(service, userId) {
    await service.reactivateUser(userId);
    await load(service);
  }

  return {
    snapshot,
    loading,
    error,
    pendingInvites,
    acceptedInvites,
    expiredInvites,
    revokedInvites,
    suspendedUsers,
    load,
    createInvite,
    revokeInvite,
    extendInvite,
    suspendUser,
    reactivateUser,
  };
});

export default useTeamAccessStore;
