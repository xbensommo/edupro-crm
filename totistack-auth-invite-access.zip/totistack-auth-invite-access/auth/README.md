# Totistack invite-only access kit

This package replaces open registration with an invitation workflow and adds suspension-based lockout.

## Included

- `pages/TeamAccessPage.vue`
- `pages/AcceptInvitePage.vue`
- `services/createInviteAccessService.js`
- `services/createAuthAccessService.js`
- `definitions/users.definitions.js`
- `definitions/user_invites.definitions.js`
- `stores/useTeamAccessStore.js`
- `routes/index.js`
- helper tests

## What changes

- public registration is closed
- invitation links can expire, be revoked, or be extended
- accepted invites create the `users` profile with role, roles, department, and permissions
- suspended users are denied during auth sync and signed out
- social sign-in no longer creates new accounts silently

## Expected app-store bindings

Expose these methods on your root app store so the pages work directly:

- `createInvite(payload)`
- `validateInviteToken(token)`
- `acceptInviteRegistration(payload)`
- `loadTeamAccessSnapshot()`
- `revokeInvite(inviteId)`
- `extendInvite(inviteId, expiresAt)`
- `suspendUser(userId, reason)`
- `reactivateUser(userId)`

The easiest path is to instantiate `createInviteAccessService(...)` once in your auth feature bootstrap, then forward those methods from your root store.

## Security note

The UI and client service lock out suspended users by enforcing `users.status` during auth sync. For hard account disable at the Firebase Auth layer, pass an optional `serverBridge` with:

- `disableAuthUser(uid)`
- `enableAuthUser(uid)`

That bridge should call a secure Cloud Function or Firebase Admin backend.
