/**
 * @file auth/services/createAccessModuleBindings.js
 * @description Convenience bindings for exposing invite access service methods on the root app store.
 */

export function createAccessModuleBindings({ authAccessService, inviteAccessService }) {
  return {
    validateInviteToken(token) {
      return inviteAccessService.validateInviteToken(token);
    },
    acceptInviteRegistration(payload) {
      return authAccessService.acceptInviteRegistration(payload);
    },
    createInvite(payload) {
      return inviteAccessService.createInvite(payload);
    },
    loadTeamAccessSnapshot() {
      return inviteAccessService.loadTeamAccessSnapshot();
    },
    revokeInvite(inviteId) {
      return inviteAccessService.revokeInvite(inviteId);
    },
    extendInvite(inviteId, expiresAt) {
      return inviteAccessService.extendInvite(inviteId, expiresAt);
    },
    suspendUser(userId, reason) {
      return inviteAccessService.suspendUser(userId, reason);
    },
    reactivateUser(userId) {
      return inviteAccessService.reactivateUser(userId);
    },
  };
}

export default createAccessModuleBindings;
