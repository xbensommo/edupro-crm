/**
 * @file auth/services/createInviteAccessService.js
 * @description Invite management and access control service for invite-only onboarding.
 */

import { createUserWithEmailAndPassword, sendEmailVerification, signOut, updateProfile as updateFirebaseProfile } from 'firebase/auth';
import { createShardedActions } from '@xbensommo/shard-provider';
import {
  ACCESS_STATUSES,
  INVITE_STATUSES,
  assertProfileCanAccess,
  createAccessError,
  generateInviteToken,
  hashInviteToken,
  isInviteUsable,
  normalizeEmail,
  normalizeStringArray,
  resolveInviteExpiry,
} from '../utils/inviteAccess.helpers.js';

/**
 * @param {object} params
 * @param {import('firebase/auth').Auth} params.auth
 * @param {object} params.state
 * @param {object} params.shardProvider
 * @param {Function} [params.collectionActions]
 * @param {object} [params.config]
 * @param {object} [params.storeApi]
 * @param {object} [params.serverBridge]
 */
export function createInviteAccessService({
  auth,
  state,
  shardProvider,
  collectionActions,
  config = {},
  storeApi,
  serverBridge,
}) {
  const usersCollectionName = config?.profileCollection || 'users';
  const invitesCollectionName = config?.invitesCollection || 'user_invites';
  const appBaseUrl = config?.appBaseUrl || globalThis?.location?.origin || '';
  const invitePath = config?.invitePath || '/accept-invite';

  const resolveActions = (collectionName) => {
    if (typeof collectionActions === 'function') {
      return collectionActions(collectionName);
    }
    return createShardedActions(collectionName, state, shardProvider);
  };

  const usersActions = resolveActions(usersCollectionName);
  const invitesActions = resolveActions(invitesCollectionName);

  async function getInviteById(inviteId) {
    return invitesActions.getById(inviteId);
  }

  async function getUserProfileById(userId) {
    return usersActions.getById(userId);
  }

  async function listCollection(itemsActions, pageSize = 100) {
    const result = await itemsActions.fetchInitialPage({ pageSize });

    if (Array.isArray(result)) return result;
    if (Array.isArray(result?.items)) return result.items;
    if (Array.isArray(result?.data)) return result.data;
    return [];
  }

  async function findInviteByToken(token) {
    const tokenHash = await hashInviteToken(token);
    const invites = await listCollection(invitesActions, 200);
    return invites.find((invite) => invite?.tokenHash === tokenHash || invite?.token === tokenHash) || null;
  }

  async function validateInviteToken(token) {
    const invite = await findInviteByToken(token);

    if (!invite) {
      throw createAccessError('auth/invite-not-found', 'This invitation could not be found.');
    }

    if (!isInviteUsable(invite)) {
      const expired = new Date(invite.expiresAt || 0).getTime() <= Date.now();
      throw createAccessError(
        expired ? 'auth/invite-expired' : 'auth/invite-unavailable',
        expired ? 'This invitation has expired.' : 'This invitation is no longer available.',
        { inviteId: invite.id || invite.uid || null },
      );
    }

    return invite;
  }

  async function createInvite(payload = {}) {
    const now = new Date();
    const email = normalizeEmail(payload.email);
    if (!email) {
      throw createAccessError('auth/invite-email-required', 'An email address is required to create an invitation.');
    }

    const existingInvites = await listCollection(invitesActions, 200);
    const conflictingInvite = existingInvites.find((invite) => normalizeEmail(invite.email) === email && invite.status === INVITE_STATUSES.PENDING);

    if (conflictingInvite) {
      throw createAccessError('auth/invite-already-pending', 'This email already has a pending invitation.', {
        inviteId: conflictingInvite.id || null,
      });
    }

    const token = generateInviteToken();
    const tokenHash = await hashInviteToken(token);
    const expiresAt = payload.expiresAt ? new Date(payload.expiresAt) : resolveInviteExpiry(payload.expiryPreset || '72h', now);
    const role = payload.role || config?.rbac?.defaultRole || 'user';
    const roles = normalizeStringArray(payload.roles?.length ? payload.roles : [role]);
    const inviteUrl = `${String(appBaseUrl).replace(/\/$/, '')}${invitePath}?token=${encodeURIComponent(token)}`;

    const invite = {
      email,
      firstName: payload.firstName || '',
      lastName: payload.lastName || '',
      displayName: payload.displayName || `${payload.firstName || ''} ${payload.lastName || ''}`.trim(),
      department: payload.department || '',
      jobTitle: payload.jobTitle || '',
      role,
      roles,
      permissions: normalizeStringArray(payload.permissions),
      status: INVITE_STATUSES.PENDING,
      tokenHash,
      inviteUrl,
      invitedBy: payload.invitedBy || auth?.currentUser?.uid || '',
      invitedByName: payload.invitedByName || auth?.currentUser?.displayName || '',
      note: payload.note || '',
      expiresAt,
      acceptedAt: null,
      acceptedByUid: null,
      acceptedEmail: null,
      revokedAt: null,
      revokedBy: null,
      createdAt: now,
      updatedAt: now,
    };

    const created = await invitesActions.add(invite);
    return {
      ...invite,
      id: created?.id || created?.uid || invite.id,
      rawToken: token,
    };
  }

  async function acceptInviteRegistration({ token, password, profileData = {} } = {}) {
    const invite = await validateInviteToken(token);
    const email = normalizeEmail(invite.email);

    if (!password || String(password).length < 8) {
      throw createAccessError('auth/weak-password', 'Password must be at least 8 characters.');
    }

    const credential = await createUserWithEmailAndPassword(auth, email, password);
    const firebaseUser = credential.user;
    const displayName = profileData.displayName || invite.displayName || `${profileData.firstName || invite.firstName || ''} ${profileData.lastName || invite.lastName || ''}`.trim();

    if (displayName) {
      await updateFirebaseProfile(firebaseUser, { displayName });
    }

    const timestamp = new Date();
    const profile = {
      uid: firebaseUser.uid,
      email,
      displayName,
      firstName: profileData.firstName || invite.firstName || '',
      lastName: profileData.lastName || invite.lastName || '',
      phoneNumber: profileData.phoneNumber || '',
      photoURL: firebaseUser.photoURL || '',
      role: invite.role || config?.rbac?.defaultRole || 'user',
      roles: normalizeStringArray(invite.roles?.length ? invite.roles : [invite.role || config?.rbac?.defaultRole || 'user']),
      permissions: normalizeStringArray(invite.permissions),
      department: invite.department || '',
      jobTitle: invite.jobTitle || '',
      status: ACCESS_STATUSES.ACTIVE,
      emailVerified: firebaseUser.emailVerified,
      inviteId: invite.id || null,
      joinedAt: timestamp,
      createdAt: timestamp,
      lastLoginAt: timestamp,
      updatedAt: timestamp,
      suspendedAt: null,
      suspendedBy: null,
      suspensionReason: '',
    };

    await usersActions.setById(firebaseUser.uid, profile);
    await invitesActions.update(invite.id, {
      status: INVITE_STATUSES.ACCEPTED,
      acceptedAt: timestamp,
      acceptedByUid: firebaseUser.uid,
      acceptedEmail: email,
      updatedAt: timestamp,
    });

    await sendEmailVerification(firebaseUser).catch(() => undefined);
    return profile;
  }

  async function revokeInvite(inviteId) {
    const timestamp = new Date();
    await invitesActions.update(inviteId, {
      status: INVITE_STATUSES.REVOKED,
      revokedAt: timestamp,
      revokedBy: auth?.currentUser?.uid || '',
      updatedAt: timestamp,
    });
  }

  async function extendInvite(inviteId, expiresAt) {
    await invitesActions.update(inviteId, {
      expiresAt: new Date(expiresAt),
      updatedAt: new Date(),
    });
  }

  async function suspendUser(userId, reason = '') {
    const timestamp = new Date();
    await usersActions.update(userId, {
      status: ACCESS_STATUSES.SUSPENDED,
      suspendedAt: timestamp,
      suspendedBy: auth?.currentUser?.uid || '',
      suspensionReason: reason || 'Suspended by administrator.',
      updatedAt: timestamp,
    });

    if (typeof serverBridge?.disableAuthUser === 'function') {
      await serverBridge.disableAuthUser(userId);
    }
  }

  async function reactivateUser(userId) {
    const timestamp = new Date();
    await usersActions.update(userId, {
      status: ACCESS_STATUSES.ACTIVE,
      suspendedAt: null,
      suspendedBy: null,
      suspensionReason: '',
      updatedAt: timestamp,
    });

    if (typeof serverBridge?.enableAuthUser === 'function') {
      await serverBridge.enableAuthUser(userId);
    }
  }

  async function assertUserCanAccess(firebaseUser) {
    if (!firebaseUser?.uid) {
      throw createAccessError('auth/no-session', 'An authenticated session is required.');
    }

    const profile = await usersActions.getById(firebaseUser.uid);
    assertProfileCanAccess(profile);
    return profile;
  }

  async function forceLogoutIfBlocked(firebaseUser) {
    try {
      await assertUserCanAccess(firebaseUser);
      return false;
    } catch (error) {
      await signOut(auth).catch(() => undefined);
      storeApi?.clearAccessState?.();
      throw error;
    }
  }

  async function loadTeamAccessSnapshot() {
    const [users, invites] = await Promise.all([
      listCollection(usersActions, 200),
      listCollection(invitesActions, 200),
    ]);

    const now = Date.now();
    const hydratedInvites = invites.map((invite) => {
      if (invite.status === INVITE_STATUSES.PENDING && new Date(invite.expiresAt || 0).getTime() <= now) {
        return { ...invite, status: INVITE_STATUSES.EXPIRED };
      }
      return invite;
    });

    return {
      users,
      invites: hydratedInvites,
      metrics: {
        pendingInvites: hydratedInvites.filter((invite) => invite.status === INVITE_STATUSES.PENDING).length,
        acceptedInvites: hydratedInvites.filter((invite) => invite.status === INVITE_STATUSES.ACCEPTED).length,
        expiredInvites: hydratedInvites.filter((invite) => invite.status === INVITE_STATUSES.EXPIRED).length,
        suspendedUsers: users.filter((user) => user.status === ACCESS_STATUSES.SUSPENDED).length,
      },
    };
  }

  return {
    createInvite,
    validateInviteToken,
    acceptInviteRegistration,
    revokeInvite,
    extendInvite,
    suspendUser,
    reactivateUser,
    assertUserCanAccess,
    forceLogoutIfBlocked,
    loadTeamAccessSnapshot,
    getInviteById,
    getUserProfileById,
  };
}

export default createInviteAccessService;
