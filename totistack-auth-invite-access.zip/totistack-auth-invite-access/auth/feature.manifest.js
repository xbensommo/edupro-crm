export default {
  name: 'auth-invite-access',
  label: 'Auth Invite Access',
  version: '1.0.0',
  routes: ['./routes/index.js'],
  definitions: ['./definitions/users.definitions.js', './definitions/user_invites.definitions.js'],
  services: ['./services/createAuthAccessService.js', './services/createInviteAccessService.js', './services/createAccessModuleBindings.js'],
  stores: ['./stores/useTeamAccessStore.js'],
};
