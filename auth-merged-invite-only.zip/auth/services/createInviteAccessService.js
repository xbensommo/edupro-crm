/**
 * @file auth/services/createInviteAccessService.js
 * @description Invite lifecycle and access enforcement service for invite-only onboarding.
 */

import {
  createUserWithEmailAndPassword,
  sendEmailVerification,
  signOut,
  updateProfile as updateFirebaseProfile,
} from 'firebase/auth'
import { createShardedActions } from '@xbensommo/shard-provider'
import { normalizeAuthError } from '../utils/auth.errors.js'
import {
  ACCESS_STATUSES,
  INVITE_STATUSES,
  assertProfileCanAccess,
  createAccessError,
  generateInviteToken,
  hashInviteToken,
  isInviteUsable,
  normalizeEmail,
  normalizeStringArray,
  resolveInviteExpiry,
} from '../utils/inviteAccess.helpers.js'

/**
 * Build invite/access operations over the `users` and `user_invites` collections.
 *
 * @param {object} params
 * @param {import('firebase/auth').Auth} params.auth
 * @param {object} params.state
 * @param {object} params.shardProvider
 * @param {(collectionName: string) => object} [params.collectionActions]
 * @param {object} [params.config={}]
 * @param {object} [params.storeApi]
 * @param {{ disableAuthUser?: (uid: string) => Promise<any>, enableAuthUser?: (uid: string) => Promise<any> }} [params.serverBridge]
 * @returns {object}
 */
export function createInviteAccessService({
  auth,
  state,
  shardProvider,
  collectionActions,
  config = {},
  storeApi,
  serverBridge,
}) {
  const usersCollectionName = config?.profileCollection || 'users'
  const invitesCollectionName = config?.invitesCollection || 'user_invites'
  const invitePath = config?.invitePath || '/accept-invite'
  const appBaseUrl = String(config?.appBaseUrl || globalThis?.location?.origin || '').replace(/\/$/, '')

  /**
   * @param {string} collectionName
   * @returns {object}
   */
  function resolveActions(collectionName) {
    if (typeof collectionActions === 'function') {
      return collectionActions(collectionName)
    }
    return createShardedActions(collectionName, state, shardProvider)
  }

  const usersActions = resolveActions(usersCollectionName)
  const invitesActions = resolveActions(invitesCollectionName)

  /**
   * Read a normalized array from a sharded-actions page call.
   *
   * @param {object} actions
   * @param {number} [pageSize=200]
   * @returns {Promise<Array<Record<string, any>>>}
   */
  async function listCollection(actions, pageSize = 200) {
    const result = await actions.fetchInitialPage({ pageSize })
    if (Array.isArray(result)) return result
    if (Array.isArray(result?.items)) return result.items
    if (Array.isArray(result?.data)) return result.data
    return []
  }

  /**
   * @param {string} token
   * @returns {Promise<Record<string, any>|null>}
   */
  async function findInviteByToken(token) {
    const tokenHash = await hashInviteToken(token)
    const invites = await listCollection(invitesActions)
    return invites.find((invite) => invite?.tokenHash === tokenHash || invite?.token === tokenHash) || null
  }

  /**
   * Return a single invite document by id.
   *
   * @param {string} inviteId
   * @returns {Promise<Record<string, any>>}
   */
  async function getInviteById(inviteId) {
    return invitesActions.getById(inviteId)
  }

  /**
   * Return a single user profile document by id.
   *
   * @param {string} userId
   * @returns {Promise<Record<string, any>>}
   */
  async function getUserProfileById(userId) {
    return usersActions.getById(userId)
  }

  /**
   * Validate a raw invite token and return the invite document.
   *
   * @param {string} token
   * @returns {Promise<Record<string, any>>}
   */
  async function validateInviteToken(token) {
    try {
      const invite = await findInviteByToken(token)

      if (!invite) {
        throw createAccessError('auth/invite-not-found', 'This invitation could not be found.')
      }

      if (!isInviteUsable(invite)) {
        const expired = new Date(invite.expiresAt || 0).getTime() <= Date.now()
        throw createAccessError(
          expired ? 'auth/invite-expired' : 'auth/invite-unavailable',
          expired ? 'This invitation has expired.' : 'This invitation is no longer available.',
          { inviteId: invite.id || invite.uid || null },
        )
      }

      return invite
    } catch (error) {
      throw normalizeAuthError(error)
    }
  }

  /**
   * Create a pending team invite and return it with the raw URL token.
   *
   * @param {Record<string, any>} [payload={}]
   * @returns {Promise<Record<string, any>>}
   */
  async function createInvite(payload = {}) {
    try {
      const now = new Date()
      const email = normalizeEmail(payload.email)

      if (!email) {
        throw createAccessError('auth/invite-email-required', 'An email address is required to create an invitation.')
      }

      const existingInvites = await listCollection(invitesActions)
      const conflictingInvite = existingInvites.find((invite) => (
        normalizeEmail(invite.email) === email && invite.status === INVITE_STATUSES.PENDING
      ))

      if (conflictingInvite) {
        throw createAccessError('auth/invite-already-pending', 'This email already has a pending invitation.', {
          inviteId: conflictingInvite.id || conflictingInvite.uid || null,
        })
      }

      const token = generateInviteToken()
      const tokenHash = await hashInviteToken(token)
      const role = payload.role || config?.rbac?.defaultRole || 'user'
      const roles = normalizeStringArray(payload.roles?.length ? payload.roles : [role])
      const expiresAt = payload.expiresAt
        ? new Date(payload.expiresAt)
        : resolveInviteExpiry(payload.expiryPreset || '72h', now)
      const inviteUrl = `${appBaseUrl}${invitePath}?token=${encodeURIComponent(token)}`

      const invite = {
        email,
        firstName: payload.firstName || '',
        lastName: payload.lastName || '',
        displayName: payload.displayName || `${payload.firstName || ''} ${payload.lastName || ''}`.trim(),
        department: payload.department || '',
        jobTitle: payload.jobTitle || '',
        role,
        roles,
        permissions: normalizeStringArray(payload.permissions),
        status: INVITE_STATUSES.PENDING,
        tokenHash,
        inviteUrl,
        invitedBy: payload.invitedBy || auth?.currentUser?.uid || '',
        invitedByName: payload.invitedByName || auth?.currentUser?.displayName || '',
        note: payload.note || '',
        acceptedAt: null,
        acceptedByUid: null,
        acceptedEmail: null,
        revokedAt: null,
        revokedBy: null,
        expiresAt,
        createdAt: now,
        updatedAt: now,
      }

      const created = await invitesActions.add(invite)

      return {
        ...invite,
        id: created?.id || created?.uid || invite.id,
        rawToken: token,
      }
    } catch (error) {
      throw normalizeAuthError(error)
    }
  }

  /**
   * Redeem a valid invite and create the corresponding Firebase/Auth profile.
   *
   * @param {{ token?: string, password?: string, profileData?: Record<string, any> }} [payload={}]
   * @returns {Promise<Record<string, any>>}
   */
  async function acceptInviteRegistration({ token, password, profileData = {} } = {}) {
    try {
      const invite = await validateInviteToken(token)
      const email = normalizeEmail(invite.email)

      if (!password || String(password).length < 8) {
        throw createAccessError('auth/weak-password', 'Password must be at least 8 characters.')
      }

      const credential = await createUserWithEmailAndPassword(auth, email, password)
      const firebaseUser = credential.user
      const timestamp = new Date()
      const displayName = profileData.displayName
        || invite.displayName
        || `${profileData.firstName || invite.firstName || ''} ${profileData.lastName || invite.lastName || ''}`.trim()

      if (displayName) {
        await updateFirebaseProfile(firebaseUser, { displayName })
      }

      const profile = {
        uid: firebaseUser.uid,
        email,
        displayName,
        firstName: profileData.firstName || invite.firstName || '',
        lastName: profileData.lastName || invite.lastName || '',
        phoneNumber: profileData.phoneNumber || '',
        photoURL: firebaseUser.photoURL || '',
        role: invite.role || config?.rbac?.defaultRole || 'user',
        roles: normalizeStringArray(invite.roles?.length ? invite.roles : [invite.role || config?.rbac?.defaultRole || 'user']),
        permissions: normalizeStringArray(invite.permissions),
        department: invite.department || '',
        jobTitle: invite.jobTitle || '',
        status: ACCESS_STATUSES.ACTIVE,
        emailVerified: firebaseUser.emailVerified,
        inviteId: invite.id || null,
        joinedAt: timestamp,
        lastLoginAt: timestamp,
        createdAt: timestamp,
        updatedAt: timestamp,
        suspendedAt: null,
        suspendedBy: null,
        suspensionReason: '',
      }

      await usersActions.setById(firebaseUser.uid, profile)
      await invitesActions.update(invite.id, {
        status: INVITE_STATUSES.ACCEPTED,
        acceptedAt: timestamp,
        acceptedByUid: firebaseUser.uid,
        acceptedEmail: email,
        updatedAt: timestamp,
      })

      await sendEmailVerification(firebaseUser).catch(() => undefined)
      return profile
    } catch (error) {
      throw normalizeAuthError(error)
    }
  }

  /**
   * Revoke a pending invite.
   *
   * @param {string} inviteId
   * @returns {Promise<void>}
   */
  async function revokeInvite(inviteId) {
    try {
      const timestamp = new Date()
      await invitesActions.update(inviteId, {
        status: INVITE_STATUSES.REVOKED,
        revokedAt: timestamp,
        revokedBy: auth?.currentUser?.uid || '',
        updatedAt: timestamp,
      })
    } catch (error) {
      throw normalizeAuthError(error)
    }
  }

  /**
   * Extend the expiry date of an existing invite.
   *
   * @param {string} inviteId
   * @param {Date|string|number} expiresAt
   * @returns {Promise<void>}
   */
  async function extendInvite(inviteId, expiresAt) {
    try {
      await invitesActions.update(inviteId, {
        expiresAt: new Date(expiresAt),
        updatedAt: new Date(),
      })
    } catch (error) {
      throw normalizeAuthError(error)
    }
  }

  /**
   * Suspend a user profile and optionally disable the backend auth account.
   *
   * @param {string} userId
   * @param {string} [reason='']
   * @returns {Promise<void>}
   */
  async function suspendUser(userId, reason = '') {
    try {
      const timestamp = new Date()
      await usersActions.update(userId, {
        status: ACCESS_STATUSES.SUSPENDED,
        suspendedAt: timestamp,
        suspendedBy: auth?.currentUser?.uid || '',
        suspensionReason: reason || 'Suspended by administrator.',
        updatedAt: timestamp,
      })

      if (typeof serverBridge?.disableAuthUser === 'function') {
        await serverBridge.disableAuthUser(userId)
      }
    } catch (error) {
      throw normalizeAuthError(error)
    }
  }

  /**
   * Reactivate a suspended user profile and optionally re-enable the backend account.
   *
   * @param {string} userId
   * @returns {Promise<void>}
   */
  async function reactivateUser(userId) {
    try {
      const timestamp = new Date()
      await usersActions.update(userId, {
        status: ACCESS_STATUSES.ACTIVE,
        suspendedAt: null,
        suspendedBy: null,
        suspensionReason: '',
        updatedAt: timestamp,
      })

      if (typeof serverBridge?.enableAuthUser === 'function') {
        await serverBridge.enableAuthUser(userId)
      }
    } catch (error) {
      throw normalizeAuthError(error)
    }
  }

  /**
   * Ensure the current Firebase user still has app access.
   *
   * @param {{ uid?: string }|null|undefined} firebaseUser
   * @returns {Promise<Record<string, any>>}
   */
  async function assertUserCanAccess(firebaseUser) {
    try {
      if (!firebaseUser?.uid) {
        throw createAccessError('auth/no-session', 'An authenticated session is required.')
      }

      const profile = await usersActions.getById(firebaseUser.uid)
      assertProfileCanAccess(profile)
      return profile
    } catch (error) {
      throw normalizeAuthError(error)
    }
  }

  /**
   * Force logout when an authenticated profile no longer has app access.
   *
   * @param {{ uid?: string }|null|undefined} firebaseUser
   * @returns {Promise<boolean>}
   */
  async function forceLogoutIfBlocked(firebaseUser) {
    try {
      await assertUserCanAccess(firebaseUser)
      return false
    } catch (error) {
      await signOut(auth).catch(() => undefined)
      storeApi?.clearAccessState?.()
      throw normalizeAuthError(error)
    }
  }

  /**
   * Load the team-access dashboard snapshot.
   *
   * @returns {Promise<{ users: Array<Record<string, any>>, invites: Array<Record<string, any>>, metrics: Record<string, number> }>} 
   */
  async function loadTeamAccessSnapshot() {
    try {
      const [users, invites] = await Promise.all([
        listCollection(usersActions),
        listCollection(invitesActions),
      ])

      const now = Date.now()
      const hydratedInvites = invites.map((invite) => {
        if (invite.status === INVITE_STATUSES.PENDING && new Date(invite.expiresAt || 0).getTime() <= now) {
          return { ...invite, status: INVITE_STATUSES.EXPIRED }
        }
        return invite
      })

      return {
        users,
        invites: hydratedInvites,
        metrics: {
          pendingInvites: hydratedInvites.filter((invite) => invite.status === INVITE_STATUSES.PENDING).length,
          acceptedInvites: hydratedInvites.filter((invite) => invite.status === INVITE_STATUSES.ACCEPTED).length,
          expiredInvites: hydratedInvites.filter((invite) => invite.status === INVITE_STATUSES.EXPIRED).length,
          suspendedUsers: users.filter((user) => user.status === ACCESS_STATUSES.SUSPENDED).length,
        },
      }
    } catch (error) {
      throw normalizeAuthError(error)
    }
  }

  return {
    createInvite,
    validateInviteToken,
    acceptInviteRegistration,
    revokeInvite,
    extendInvite,
    suspendUser,
    reactivateUser,
    assertUserCanAccess,
    forceLogoutIfBlocked,
    loadTeamAccessSnapshot,
    getInviteById,
    getUserProfileById,
  }
}

export default createInviteAccessService
