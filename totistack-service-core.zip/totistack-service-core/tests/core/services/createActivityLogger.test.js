import test from 'node:test'
import assert from 'node:assert/strict'

import { createServiceContext } from '../../../src/core/services/context/createServiceContext.js'
import { createActivityLogger } from '../../../src/core/services/hooks/createActivityLogger.js'

function createStore() {
  const writes = []

  return {
    writes,
    currentUser: { value: { uid: 'user_1', email: 'user@example.com' } },
    rbacEnabled: { value: false },
    clientActivitiesActions: {
      async setById(id, payload) {
        writes.push({ id, payload })
        return { id, ...payload }
      },
    },
  }
}

test('createActivityLogger stamps actor and audit fields and writes through setById', async () => {
  const store = createStore()
  const context = createServiceContext({ store })
  const logActivity = createActivityLogger({
    context,
    collectionName: 'clientActivities',
    buildRecord(payload, { currentUser }) {
      return {
        clientId: payload.clientId,
        userId: currentUser.uid,
        type: payload.type || 'note',
        description: payload.description || '',
      }
    },
  })

  const result = await logActivity({
    clientId: 'client_1',
    type: 'note',
    description: 'Client created.',
  })

  assert.equal(result.clientId, 'client_1')
  assert.equal(result.userId, 'user_1')
  assert.ok(result.createdAt instanceof Date)
  assert.equal(store.writes.length, 1)
})
