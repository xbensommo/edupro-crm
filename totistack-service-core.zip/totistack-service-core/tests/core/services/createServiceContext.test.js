import test from 'node:test'
import assert from 'node:assert/strict'

import { createServiceContext } from '../../../src/core/services/context/createServiceContext.js'
import { ServiceError } from '../../../src/core/services/errors/ServiceError.js'

test('createServiceContext resolves current user from ref-like store values', () => {
  const context = createServiceContext({
    store: {
      currentUser: { value: { uid: 'user_1', email: 'user@example.com' } },
      rbacEnabled: { value: false },
    },
  })

  assert.equal(context.getCurrentUserId(), 'user_1')
  assert.equal(context.getCurrentUserEmail(), 'user@example.com')
  assert.equal(context.isAuthenticated(), true)
})

test('createServiceContext resolves actions from several root-store patterns', () => {
  const store = {
    currentUser: { value: { uid: 'user_1' } },
    rbacEnabled: { value: false },
    clientsActions: { fetchInitialPage() {} },
    collectionsActions: {
      bookings: { add() {} },
    },
    getCollectionActions(name) {
      if (name === 'crm_leads') return { getById() {} }
      return null
    },
  }

  const context = createServiceContext({ store })

  assert.equal(typeof context.getCollectionActions('clients').fetchInitialPage, 'function')
  assert.equal(typeof context.getCollectionActions('bookings').add, 'function')
  assert.equal(typeof context.getCollectionActions('crm_leads').getById, 'function')
})

test('createServiceContext denies access when explicit access object returns false', () => {
  const context = createServiceContext({
    store: {
      currentUser: { value: { uid: 'user_1' } },
      rbacEnabled: { value: false },
    },
    access: {
      can() {
        return false
      },
    },
    domain: 'clients',
  })

  assert.throws(
    () => context.assertPermission('clients.read'),
    /** @param {unknown} error */
    (error) => error instanceof ServiceError && error.code === 'FORBIDDEN' && error.domain === 'clients',
  )
})
