import test from 'node:test'
import assert from 'node:assert/strict'

import { createCollectionAdapter } from '../../../src/core/services/collections/createCollectionAdapter.js'
import { createServiceContext } from '../../../src/core/services/context/createServiceContext.js'
import { ServiceError } from '../../../src/core/services/errors/ServiceError.js'

function createStore(overrides = {}) {
  return {
    currentUser: { value: { uid: 'user_1' } },
    rbacEnabled: { value: false },
    clients: { items: [{ id: 'client_1', name: 'Acme' }], hasMore: true },
    clientsActions: {
      async fetchInitialPage() {
        return { items: [{ id: 'client_1', name: 'Acme' }] }
      },
      async add(payload) {
        return { id: 'client_2', ...payload }
      },
      async update(id, payload) {
        return { id, ...payload }
      },
      async getById(id) {
        return { id, name: 'Loaded' }
      },
    },
    ...overrides,
  }
}

test('adapter lists items via fetchInitialPage and falls back to state normalization', async () => {
  const context = createServiceContext({ store: createStore() })
  const adapter = createCollectionAdapter({ context, collectionName: 'clients' })

  const items = await adapter.list({ pageSize: 10 })
  assert.equal(items.length, 1)
  assert.equal(items[0].id, 'client_1')
  assert.equal(adapter.readState().hasMore, true)
})

test('adapter creates records through add when create is unavailable', async () => {
  const context = createServiceContext({ store: createStore() })
  const adapter = createCollectionAdapter({ context, collectionName: 'clients' })

  const result = await adapter.create({ name: 'Beta' })
  assert.equal(result.id, 'client_2')
  assert.equal(result.name, 'Beta')
})

test('adapter uses setById when that is the only available create shape', async () => {
  const store = createStore({
    clientsActions: {
      async setById(id, payload) {
        return { id, ...payload }
      },
    },
  })

  const context = createServiceContext({ store })
  const adapter = createCollectionAdapter({ context, collectionName: 'clients' })

  const result = await adapter.create(
    { name: 'Gamma' },
    { id: 'client_3' },
  )

  assert.equal(result.id, 'client_3')
  assert.equal(result.name, 'Gamma')
})

test('adapter throws a stable ServiceError when id is missing for getById', async () => {
  const context = createServiceContext({ store: createStore() })
  const adapter = createCollectionAdapter({ context, collectionName: 'clients' })

  await assert.rejects(
    () => adapter.getById(''),
    /** @param {unknown} error */
    (error) => error instanceof ServiceError && error.code === 'RECORD_ID_REQUIRED',
  )
})
