/**
 * @file auth/services/createInviteAccessService.js
 * @description Invite lifecycle and access enforcement service for invite-only onboarding.
 */

import {
  createUserWithEmailAndPassword,
  sendEmailVerification,
  signOut,
  updateProfile as updateFirebaseProfile,
} from 'firebase/auth'
import { createShardedActions } from '@xbensommo/shard-provider'
import { normalizeAuthError } from '../utils/auth.errors.js'
import {
  ACCESS_STATUSES,
  INVITE_STATUSES,
  assertProfileCanAccess,
  createAccessError,
  generateInviteToken,
  hashInviteToken,
  isInviteUsable,
  normalizeEmail,
  normalizeStringArray,
  resolveInviteExpiry,
} from '../utils/inviteAccess.helpers.js'

/**
 * @param {unknown} value
 * @returns {Array<Record<string, any>>}
 */
function normalizeListResult(value) {
  if (Array.isArray(value)) return value
  if (Array.isArray(value?.items)) return value.items
  if (Array.isArray(value?.data)) return value.data
  if (Array.isArray(value?.value?.items)) return value.value.items
  return []
}

/**
 * Build invite/access operations over the `users` and `user_invites` collections.
 *
 * @param {object} params
 * @param {import('firebase/auth').Auth} params.auth
 * @param {object} params.state
 * @param {object} params.shardProvider
 * @param {(collectionName: string) => object} [params.collectionActions]
 * @param {object} [params.config={}]
 * @param {object} [params.storeApi]
 * @param {{ disableAuthUser?: (uid: string) => Promise<any>, enableAuthUser?: (uid: string) => Promise<any> }} [params.serverBridge]
 * @returns {object}
 */
export function createInviteAccessService({
  auth,
  state,
  shardProvider,
  collectionActions,
  config = {},
  storeApi,
  serverBridge,
}) {
  const usersCollectionName = config?.profileCollection || 'users'
  const invitesCollectionName = config?.invitesCollection || 'user_invites'
  const invitePath = config?.invitePath || '/accept-invite'
  const appBaseUrl = String(config?.appBaseUrl || globalThis?.location?.origin || '').replace(/\/$/, '')

  /**
   * @param {string} collectionName
   * @returns {object}
   */
  function resolveActions(collectionName) {
    if (typeof collectionActions === 'function') {
      const resolved = collectionActions(collectionName)
      if (resolved) return resolved
    }

    return createShardedActions(collectionName, state, shardProvider)
  }

  const usersActions = resolveActions(usersCollectionName)
  const invitesActions = resolveActions(invitesCollectionName)

  /**
   * @param {object} actions
   * @param {number} [pageSize=200]
   * @returns {Promise<Array<Record<string, any>>>}
   */
  async function listCollection(actions, pageSize = 200) {
    const result = await actions.fetchInitialPage({ pageSize })
    return normalizeListResult(result)
  }

  /**
   * @param {string} token
   * @returns {Promise<Record<string, any>|null>}
   */
  async function findInviteByToken(token) {
    const tokenHash = await hashInviteToken(token)
    const invites = await listCollection(invitesActions)
    return invites.find((invite) => invite?.tokenHash === tokenHash) || null
  }

  /**
   * @param {string} token
   * @returns {Promise<Record<string, any>>}
   */
  async function validateInviteToken(token) {
    try {
      if (!token) {
        throw createAccessError('auth/invite-invalid', 'An invite token is required.')
      }

      const invite = await findInviteByToken(token)
      if (!invite) {
        throw createAccessError('auth/invite-invalid', 'Invitation not found.')
      }

      if (!isInviteUsable(invite)) {
        throw createAccessError('auth/invite-expired', 'This invitation is no longer valid.')
      }

      return invite
    } catch (error) {
      throw normalizeAuthError(error)
    }
  }

  /**
   * @param {object} payload
   * @param {string} payload.email
   * @param {string} [payload.firstName]
   * @param {string} [payload.lastName]
   * @param {string} [payload.role]
   * @param {string[]} [payload.roles]
   * @param {string[]} [payload.permissions]
   * @param {string} [payload.department]
   * @param {string} [payload.jobTitle]
   * @param {Date|string|number} [payload.expiresAt]
   * @returns {Promise<Record<string, any>>}
   */
  async function createInvite(payload = {}) {
    try {
      const email = normalizeEmail(payload.email)
      if (!email) {
        throw createAccessError('auth/invite-invalid', 'Invite email is required.')
      }

      const timestamp = new Date()
      const token = await generateInviteToken()
      const tokenHash = await hashInviteToken(token)
      const expiresAt = resolveInviteExpiry(payload.expiresAt || config?.defaultInviteTtlMs)
      const inviteId = payload.id || `invite_${Date.now()}`
      const role = payload.role || config?.rbac?.defaultRole || 'user'
      const roles = normalizeStringArray(payload.roles?.length ? payload.roles : [role])
      const permissions = normalizeStringArray(payload.permissions)

      const inviteRecord = {
        email,
        firstName: payload.firstName || '',
        lastName: payload.lastName || '',
        role,
        roles,
        permissions,
        department: payload.department || '',
        jobTitle: payload.jobTitle || '',
        tokenHash,
        status: INVITE_STATUSES.PENDING,
        inviteUrl: `${appBaseUrl}${invitePath}?token=${encodeURIComponent(token)}`,
        expiresAt,
        createdAt: timestamp,
        updatedAt: timestamp,
        invitedBy: auth?.currentUser?.uid || '',
      }

      await invitesActions.setById(inviteId, inviteRecord)

      return {
        id: inviteId,
        token,
        ...inviteRecord,
      }
    } catch (error) {
      throw normalizeAuthError(error)
    }
  }

  /**
   * @param {{ token?: string, password?: string, profileData?: Record<string, any> }} [payload={}]
   * @returns {Promise<Record<string, any>>}
   */
  async function acceptInviteRegistration({ token, password, profileData = {} } = {}) {
    try {
      const invite = await validateInviteToken(token)
      const email = normalizeEmail(invite.email)

      if (!password) {
        throw createAccessError('auth/password-required', 'A password is required to accept the invitation.')
      }

      const credential = await createUserWithEmailAndPassword(auth, email, password)
      const firebaseUser = credential.user
      const timestamp = new Date()
      const displayName = `${profileData.firstName || invite.firstName || ''} ${profileData.lastName || invite.lastName || ''}`.trim()

      if (displayName) {
        await updateFirebaseProfile(firebaseUser, { displayName })
      }

      const profile = {
        uid: firebaseUser.uid,
        email,
        displayName,
        firstName: profileData.firstName || invite.firstName || '',
        lastName: profileData.lastName || invite.lastName || '',
        phoneNumber: profileData.phoneNumber || '',
        photoURL: firebaseUser.photoURL || '',
        role: invite.role || config?.rbac?.defaultRole || 'user',
        roles: normalizeStringArray(invite.roles?.length ? invite.roles : [invite.role || config?.rbac?.defaultRole || 'user']),
        permissions: normalizeStringArray(invite.permissions),
        department: invite.department || '',
        jobTitle: invite.jobTitle || '',
        status: ACCESS_STATUSES.ACTIVE,
        emailVerified: firebaseUser.emailVerified,
        inviteId: invite.id || null,
        joinedAt: timestamp,
        lastLoginAt: timestamp,
        createdAt: timestamp,
        updatedAt: timestamp,
        suspendedAt: null,
        suspendedBy: null,
        suspensionReason: '',
      }

      await usersActions.setById(firebaseUser.uid, profile)
      await invitesActions.update(invite.id, {
        status: INVITE_STATUSES.ACCEPTED,
        acceptedAt: timestamp,
        acceptedByUid: firebaseUser.uid,
        acceptedEmail: email,
        updatedAt: timestamp,
      })

      await sendEmailVerification(firebaseUser).catch(() => undefined)
      return profile
    } catch (error) {
      throw normalizeAuthError(error)
    }
  }

  /**
   * @param {string} inviteId
   * @returns {Promise<void>}
   */
  async function revokeInvite(inviteId) {
    try {
      const timestamp = new Date()
      await invitesActions.update(inviteId, {
        status: INVITE_STATUSES.REVOKED,
        revokedAt: timestamp,
        revokedBy: auth?.currentUser?.uid || '',
        updatedAt: timestamp,
      })
    } catch (error) {
      throw normalizeAuthError(error)
    }
  }

  /**
   * @param {string} inviteId
   * @param {Date|string|number} expiresAt
   * @returns {Promise<void>}
   */
  async function extendInvite(inviteId, expiresAt) {
    try {
      await invitesActions.update(inviteId, {
        expiresAt: new Date(expiresAt),
        updatedAt: new Date(),
      })
    } catch (error) {
      throw normalizeAuthError(error)
    }
  }

  /**
   * @param {string} userId
   * @param {string} [reason='']
   * @returns {Promise<void>}
   */
  async function suspendUser(userId, reason = '') {
    try {
      const timestamp = new Date()
      await usersActions.update(userId, {
        status: ACCESS_STATUSES.SUSPENDED,
        suspendedAt: timestamp,
        suspendedBy: auth?.currentUser?.uid || '',
        suspensionReason: reason || 'Suspended by administrator.',
        updatedAt: timestamp,
      })

      if (typeof serverBridge?.disableAuthUser === 'function') {
        await serverBridge.disableAuthUser(userId)
      }
    } catch (error) {
      throw normalizeAuthError(error)
    }
  }

  /**
   * @param {string} userId
   * @returns {Promise<void>}
   */
  async function reactivateUser(userId) {
    try {
      const timestamp = new Date()
      await usersActions.update(userId, {
        status: ACCESS_STATUSES.ACTIVE,
        suspendedAt: null,
        suspendedBy: null,
        suspensionReason: '',
        updatedAt: timestamp,
      })

      if (typeof serverBridge?.enableAuthUser === 'function') {
        await serverBridge.enableAuthUser(userId)
      }
    } catch (error) {
      throw normalizeAuthError(error)
    }
  }

  /**
   * @param {{ uid?: string }|null|undefined} firebaseUser
   * @returns {Promise<Record<string, any>>}
   */
  async function assertUserCanAccess(firebaseUser) {
    try {
      if (!firebaseUser?.uid) {
        throw createAccessError('auth/no-session', 'An authenticated session is required.')
      }

      const profile = await usersActions.getById(firebaseUser.uid)
      assertProfileCanAccess(profile)
      return profile
    } catch (error) {
      throw normalizeAuthError(error)
    }
  }

  /**
   * @param {{ uid?: string }|null|undefined} firebaseUser
   * @returns {Promise<boolean>}
   */
  async function forceLogoutIfBlocked(firebaseUser) {
    try {
      await assertUserCanAccess(firebaseUser)
      return false
    } catch (error) {
      await signOut(auth).catch(() => undefined)
      storeApi?.clearAccessState?.()
      throw normalizeAuthError(error)
    }
  }

  /**
   * @returns {Promise<{ users: Array<Record<string, any>>, invites: Array<Record<string, any>>, metrics: Record<string, number> }>}
   */
  async function loadTeamAccessSnapshot() {
    try {
      const [users, invites] = await Promise.all([
        listCollection(usersActions),
        listCollection(invitesActions),
      ])

      const now = Date.now()
      const hydratedInvites = invites.map((invite) => {
        if (invite.status === INVITE_STATUSES.PENDING && new Date(invite.expiresAt || 0).getTime() <= now) {
          return { ...invite, status: INVITE_STATUSES.EXPIRED }
        }
        return invite
      })

      return {
        users,
        invites: hydratedInvites,
        metrics: {
          pendingInvites: hydratedInvites.filter((invite) => invite.status === INVITE_STATUSES.PENDING).length,
          acceptedInvites: hydratedInvites.filter((invite) => invite.status === INVITE_STATUSES.ACCEPTED).length,
          expiredInvites: hydratedInvites.filter((invite) => invite.status === INVITE_STATUSES.EXPIRED).length,
          suspendedUsers: users.filter((user) => user.status === ACCESS_STATUSES.SUSPENDED).length,
        },
      }
    } catch (error) {
      throw normalizeAuthError(error)
    }
  }

  return {
    createInvite,
    validateInviteToken,
    acceptInviteRegistration,
    revokeInvite,
    extendInvite,
    suspendUser,
    reactivateUser,
    assertUserCanAccess,
    forceLogoutIfBlocked,
    loadTeamAccessSnapshot,
  }
}

export default createInviteAccessService
