# Totistack Updated Services

This bundle contains updated production-ready service files rewritten to use the shared service core where appropriate.

Included paths:
- `booking/services/bookingService.js`
- `services/clientService.js`
- `apps/crm/services/crmService.js`
- `auth/services/create-auth-access-service.js`
- `auth/services/createInviteAccessService.js`
