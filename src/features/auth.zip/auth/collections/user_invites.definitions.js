/**
 * @file auth/definitions/user_invites.definitions.js
 * @description Pending team invitations for onboarding staff members.
 */

import { FIELD_TYPES, defineCollection } from '@xbensommo/shard-provider';

export default defineCollection({
  name: 'user_invites',
  shard: { type: 'none' },
  schema: {
    email: { type: FIELD_TYPES.STRING, required: true, searchable: true, filterable: true },
    role: { type: FIELD_TYPES.STRING, required: false, filterable: true },
    roles: { type: FIELD_TYPES.ARRAY, required: false },
    status: { type: FIELD_TYPES.STRING, required: false, filterable: true, sortable: true },
    token: { type: FIELD_TYPES.STRING, required: true, filterable: true },
    expiresAt: { type: FIELD_TYPES.TIMESTAMP, required: true, filterable: true, sortable: true },
    acceptedAt: { type: FIELD_TYPES.TIMESTAMP, required: false, filterable: true, sortable: true },
    invitedBy: { type: FIELD_TYPES.STRING, required: false, filterable: true },
    createdAt: { type: FIELD_TYPES.TIMESTAMP, readonly: true, system: true, sortable: true, filterable: true },
    updatedAt: { type: FIELD_TYPES.TIMESTAMP, readonly: true, system: true, sortable: true },
  },
  writableFields: ['email', 'role', 'roles', 'status', 'token', 'expiresAt', 'acceptedAt', 'invitedBy'],
  updateableFields: ['role', 'roles', 'status', 'expiresAt', 'acceptedAt'],
  indexes: [
    { fields: ['email'] },
    { fields: ['status', 'expiresAt'] },
    { fields: ['token'] },
  ],
  search: {
    mode: 'token-array',
    fields: ['email', 'role'],
  },
  rules: {
    read: 'adminOnly',
    create: 'adminOnly',
    update: 'adminOnly',
    delete: 'adminOnly',
  },
});
