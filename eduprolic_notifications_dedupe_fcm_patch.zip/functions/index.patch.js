/** @file functions/index.patch.js */

// Keep your existing index.js, then add this export line:
Object.assign(exports, require('./pushNotificationWorker.js'))
