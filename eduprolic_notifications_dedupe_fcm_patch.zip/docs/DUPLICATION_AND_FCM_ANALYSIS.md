# EduProLIC Notifications — Duplication Analysis and FCM Enablement

## Duplication found

The uploaded notification feature already dedupes recipients inside `createNotificationRecipientsService.js` and partially inside `createNotificationOrchestrator.js`. That is not enough.

The real database duplication comes from these write paths:

1. `createNotificationDispatcher.js` always calls `repository.saveNotification(...)`.
2. `createNotificationRepository.js` calls `notifications.add(...)` directly.
3. `queueDelivery(...)` calls `notification_delivery_queue.add(...)` directly.
4. `saveLog(...)` calls `notification_logs.add(...)` directly.

Therefore, if the same CRM action is emitted twice, the same notification record is created twice. Recipient dedupe only protects one function call. It does not protect the database.

## Common double-fire path in EduProLIC CRM

The most likely app-level duplicate path is:

```text
AddEngagementPage.vue emits notifyWorkCreated / notifyWorkAssignment
AND
crmService.createEngagements(...) also emits the same notification internally
```

That creates the same event twice with the same recipient. The patch does not rely on you finding every double emitter immediately. It makes writes deterministic by dedupe key.

## Fix applied

The patch adds database-level idempotency:

```text
same event + same entity + same recipient + same channel + same occurrence = same record
```

The repository now:

- checks `dedupeKey` before writing;
- uses deterministic document IDs when `setById` exists;
- returns `_deduped: true` for existing records;
- stops the dispatcher from writing duplicate logs and duplicate delivery queue rows.

## FCM/browser push enabled

The patch adds:

- `notification_push_tokens` collection definition;
- browser FCM token registration service;
- `useBrowserNotifications()` composable;
- permission card component;
- `/public/firebase-messaging-sw.js` service worker;
- Firebase Function `pushNotificationWorker.js` to process `channel: 'push'` queue rows.

## Required manual setup

1. In Firebase Console, enable Cloud Messaging / FCM HTTP v1 API.
2. Generate a Web Push certificate key pair and copy the public VAPID key.
3. Add this to `.env`:

```env
VITE_FIREBASE_MESSAGING_VAPID_KEY=your_public_vapid_key
```

4. Replace the config placeholders in `public/firebase-messaging-sw.js` with your Firebase web app config.
5. Export the new collection definition in `src/features/notifications/index.js`.
6. Add `notification_push_tokens` to the feature manifest collections.
7. Add the push worker export in `functions/index.js`:

```js
Object.assign(exports, require('./pushNotificationWorker.js'))
```

8. Deploy indexes and rules.

## Test sequence

1. Register browser token from the UI.
2. Confirm one document exists in `notification_push_tokens` for the logged-in user.
3. Create one engagement assigned to one consultant.
4. Confirm one row in `notifications` for that consultant.
5. Confirm one row in `notification_delivery_queue` for `channel: push`.
6. Confirm the push queue row moves to `sent`, `partial_sent`, `skipped`, or `failed`.

## Do not do this

Do not emit notifications from both page components and CRM services for the same action long-term. Pick one canonical owner. The correct owner is the domain service, not the page.
