/* public/firebase-messaging-sw.js
 *
 * Required for Firebase Cloud Messaging web push background notifications.
 * Replace firebaseConfig values with the same Firebase web config used by the app.
 */

/* eslint-disable no-undef */
importScripts('https://www.gstatic.com/firebasejs/10.13.2/firebase-app-compat.js')
importScripts('https://www.gstatic.com/firebasejs/10.13.2/firebase-messaging-compat.js')

firebase.initializeApp({
  apiKey: 'REPLACE_WITH_FIREBASE_API_KEY',
  authDomain: 'REPLACE_WITH_FIREBASE_AUTH_DOMAIN',
  projectId: 'REPLACE_WITH_FIREBASE_PROJECT_ID',
  storageBucket: 'REPLACE_WITH_FIREBASE_STORAGE_BUCKET',
  messagingSenderId: 'REPLACE_WITH_FIREBASE_MESSAGING_SENDER_ID',
  appId: 'REPLACE_WITH_FIREBASE_APP_ID',
})

const messaging = firebase.messaging()

messaging.onBackgroundMessage((payload) => {
  const notification = payload.notification || {}
  const data = payload.data || {}
  const title = notification.title || data.title || 'EduProLIC notification'
  const options = {
    body: notification.body || data.body || data.message || '',
    icon: data.icon || '/android-chrome-512x512.png',
    badge: data.badge || '/android-chrome-512x512.png',
    data: {
      actionUrl: data.actionUrl || '/',
      notificationId: data.notificationId || '',
    },
  }

  self.registration.showNotification(title, options)
})

self.addEventListener('notificationclick', (event) => {
  event.notification.close()
  const actionUrl = event.notification?.data?.actionUrl || '/notifications'
  event.waitUntil(clients.openWindow(actionUrl))
})
